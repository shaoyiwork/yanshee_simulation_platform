from clickclick.console import *  # noqa

__version__ = '20.10.2'
