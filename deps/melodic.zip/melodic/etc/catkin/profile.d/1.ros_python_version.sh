# generated from ros_environment/env-hooks/1.ros_python_version.sh.in

export ROS_PYTHON_VERSION=2
