
"use strict";

let AddDiagnostics = require('./AddDiagnostics.js')
let SelfTest = require('./SelfTest.js')

module.exports = {
  AddDiagnostics: AddDiagnostics,
  SelfTest: SelfTest,
};
